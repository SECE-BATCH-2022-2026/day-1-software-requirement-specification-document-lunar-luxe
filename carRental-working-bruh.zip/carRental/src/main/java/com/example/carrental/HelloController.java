package com.example.carrental;

import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class HelloController {
    @FXML
    private TextField username;
    @FXML
    private TextField email;
    @FXML
    private PasswordField pass;
    @FXML
    private PasswordField pass2;


    @FXML
    protected void register() {
        String usernameText = username.getText();
        String emailText = email.getText();
        String passText = pass.getText();
        String confirmPassText = pass2.getText();

        System.out.println(usernameText + emailText + passText);

        DbmsCon.insertUser(usernameText, passText, emailText);
    }
}
