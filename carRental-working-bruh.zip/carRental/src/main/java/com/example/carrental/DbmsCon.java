package com.example.carrental;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;

public class DbmsCon {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/carrental";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "2005";

    // Establish a connection to the database
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);
    }

    public static void closeConnection(Connection connection) {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void insertUser(String myusername, String mypassword,String email) {
        System.out.println("Insert User");
        try (Connection connection = getConnection()) {
            String insertQuery = "INSERT INTO users (username, email, password) VALUES (?,?,?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                preparedStatement.setString(1, myusername);
                preparedStatement.setString(3, mypassword);
                preparedStatement.setString(2, email);
                preparedStatement.executeUpdate();
                System.out.println("User Created.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static Map<String, Object> loginUser(String username, String password) {
        System.out.println("Login User");
        try (Connection connection = getConnection()) {
            String selectQuery = "SELECT * FROM users WHERE username = ? AND password = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(selectQuery)) {
                preparedStatement.setString(1, username);
                preparedStatement.setString(2, password);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        Map<String, Object> userData = new HashMap<>();
                        userData.put("username", resultSet.getString("username"));
                        userData.put("email", resultSet.getString("email"));
                        userData.put("password", resultSet.getString("password"));
                        userData.put("carCount", resultSet.getInt("rent"));
                        return userData;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<Car> getCarData() {
        List<Car> carList = new ArrayList<>();

        try (Connection connection = getConnection()) {
            String selectQuery = "SELECT * FROM carlist LIMIT 10";
            try (PreparedStatement preparedStatement = connection.prepareStatement(selectQuery)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String register = resultSet.getString("register");
                        String model = resultSet.getString("model");
                        String hourlyRate = resultSet.getString("hourRate");
                        String availability = resultSet.getString("availability");


                        Car car = new Car(register, model, hourlyRate, availability);
                        carList.add(car);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception according to your needs
        }

        return carList;
    }
}