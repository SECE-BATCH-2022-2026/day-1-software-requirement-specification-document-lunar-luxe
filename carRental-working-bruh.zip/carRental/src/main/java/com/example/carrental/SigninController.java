package com.example.carrental;

import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Map;
import com.example.carrental.DbmsCon;

public class SigninController {
    @FXML
    private TextField username;
    @FXML
    private PasswordField pass;
    @FXML
    protected void login() {
        String usernameText = username.getText();
        String passText = pass.getText();

        System.out.println(usernameText + passText);

        // Retrieve user data map from the loginUser method
        Map<String, Object> userData = DbmsCon.loginUser(usernameText, passText);
        System.out.println("Login Status : " + (userData != null));

        if (userData != null) {
            // Compare the entered password with the stored password
            String storedPassword = (String) userData.get("password"); // Assuming password is a String field in the database
            if (passText.equals(storedPassword)) {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("mainmenu.fxml"));
                    Parent root = loader.load();

                    // Get the controller of the new page
                    mainMenuController mainMenuController = loader.getController();
                    mainMenuController.populateTable();
                    // Set the username in the main menu controller
                    mainMenuController.setUsername(usernameText);
                    int carCount = (int) userData.get("carCount"); // Adjust the key according to your actual map structure

                    // Call setCarCount method
                    mainMenuController.setCarCount(carCount);

                    // Set the new scene
                    Scene scene = new Scene(root);
                    Stage primaryStage = (Stage) username.getScene().getWindow();
                    primaryStage.setScene(scene);
                    primaryStage.show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                System.out.println("Incorrect password");
                // Handle incorrect password scenario
            }
        } else {
            System.out.println("Login failed");
            // Handle failed login scenario
        }
    }

    @FXML
    private void handleSignUpLabelClick(MouseEvent  event) {
        System.out.println("Sign Up clicked");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("register.fxml"));

        try {
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);

        } catch (IOException e) {
            e.printStackTrace();

        }
    }
}
