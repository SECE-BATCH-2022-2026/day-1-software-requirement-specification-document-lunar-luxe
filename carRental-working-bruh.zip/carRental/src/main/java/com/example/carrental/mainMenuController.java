package com.example.carrental;

import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.util.List;
public class mainMenuController {
    @FXML
    private Label usernameLabel;
    @FXML
    private Label carLabel;
    @FXML
    private TableView<Car> carTableView;
    @FXML
    private TableColumn<Car, String> registerColumn;
    @FXML
    private TableColumn<Car, String> modelColumn;
    @FXML
    private TableColumn<Car, String> hourlyRateColumn;
    @FXML
    private TableColumn<Car, String> availabilityColumn;
    @FXML
    public void setUsername(String username) {
        usernameLabel.setText(username);
    }

    @FXML
    public void setCarCount(int carCount) {
        carLabel.setText(String.valueOf(carCount));
    }

    @FXML
    public void populateTable() {
        List<Car> carList = DbmsCon.getCarData();
        carTableView.getItems().setAll(carList);

        // Set cell values directly without JavaFX properties
        registerColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getRegister()));
        modelColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getModel()));
        hourlyRateColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getHourlyRate()));
        availabilityColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getAvailability()));
    }



}
