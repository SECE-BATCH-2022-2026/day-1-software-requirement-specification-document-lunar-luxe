package com.example.carrental;

public class Car {
    private String register;
    private String model;
    private String hourlyRate;
    private String availability;

    public Car(String register, String model, String hourlyRate, String availability) {
        this.register = register;
        this.model = model;
        this.hourlyRate = hourlyRate;
        this.availability = availability;
    }

    public String getRegister() {
        return register;
    }

    public void setRegister(String register) {
        this.register = register;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getHourlyRate() {
        return hourlyRate;
    }

    public void setHourlyRate(String hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }
}
